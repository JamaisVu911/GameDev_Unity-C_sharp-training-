﻿using System;
using SFML.System;
using SFML.Window;
using SFML.Graphics;
using SFML.Learning;
using SFML.Audio;

namespace ColorGame
{
    class Program: Game
    {
        static int playerScore;
        static int HiScore;
        static bool ModeDiff = false;
        static Color[] colors = new Color[] { Color.Blue, Color.Green, Color.Red, Color.Cyan };
        static string[] Titels = { "Синий", "Зеленый", "Красный", "Голубой" };
        static Color currentColor;
        static string currentTitle;
        static string RightColor = LoadMusic("knopka-klik-aktivnyii-blizkii-chetkii.wav");
        static string WrongColor = LoadMusic("inecraft_chest_open.wav");

        static void title()
        {
            Random rnd = new Random();
            currentColor = colors[rnd.Next(0, 4)];
            SetFillColor(currentColor);
            currentTitle = Titels[rnd.Next(0, 4)];
            DrawText(230, 260, currentTitle, 64);
            SetFillColor(Color.White);
            DrawText(230, 200, $"{playerScore}", 64);
            if (HiScore <= playerScore) HiScore = playerScore;
        }

        static void Menu()
        {
            DrawText(10, 10, "Инструкция", 20);
            DrawText(30, 30, "Укажите правильно цвет надписи", 20);
            DrawText(10, 60, "Клавиши: ", 20);
            DrawText(10, 100, "Синий    :  C", 20);
            DrawText(10, 120, "Голубой:  Г", 20);
            DrawText(10, 140, "Зеленый:  З", 20);
            DrawText(10, 160, "Красный:  К", 20);
            DrawText(10, 550, "Маскимальный результат: " + (HiScore), 16);
        }
        static void Main(string[] args)
        {
            SetFont("arial.ttf");

            InitWindow(800, 600, "Color");

            while (true)
            {
                DispatchEvents();

                ClearWindow();

                Menu();

                if (GetKeyDown(Keyboard.Key.C) == true && currentColor == Color.Blue || GetKeyDown(Keyboard.Key.P) == true && currentColor == Color.Green 
                    || GetKeyDown(Keyboard.Key.R) == true && currentColor == Color.Red || GetKeyDown(Keyboard.Key.U) == true && currentColor == Color.Cyan)
                {
                    PlayMusic(RightColor, 20);
                    playerScore++;
                }
                else
                {
                    PlayMusic(WrongColor, 20);
                    playerScore = 0;
                }


                title();

                DisplayWindow();

                Delay(3000);

            }

            Console.WriteLine();

        }
    }
}
