﻿using System;

    class Program
    {
        static void Main(string[] args)
        {
        Random rnd = new Random();
        
        int action = -1; // Объявление переменных
        int playerHealth = 100;
        int playerEnergy = 100;
        int enemyHealth = 100;
        int enemyEnergy = 100;


        while (true)
        {
            Console.Clear(); // Отображение статов и скилов
            Console.WriteLine(@"        Жизни Игрока: {0}                        Жизни противника: {1}", playerHealth, enemyHealth);
            Console.WriteLine(@"        Мана Игрока: {0}                        Мана противника: {1}", playerEnergy, enemyEnergy);
            Console.WriteLine();

            Console.WriteLine("1. Удар молнией (20 урона, -10 маны) ");
            Console.WriteLine("2. Огненный шар (30 урона, -40 маны) ");
            Console.WriteLine("3. Концентрация (+20 маны) ");
            Console.WriteLine("4. Лечение (+30 жизни, -20 маны) ");

            Console.WriteLine();

            if(playerHealth <= 0) // Отображение победы или поражения
            {
                Console.WriteLine("Противник выйграл!");
                break;
            }

            if (enemyHealth <= 0)
            {
                Console.WriteLine("Игрок выйграл!");
                break;
            }

            action = int.Parse(Console.ReadLine()); // Получение действий игрока
            

            if (action == 1) // Описание скиллов игрока
            {
                if( playerEnergy >= 10)
                {
                    enemyHealth -= 20;
                    playerEnergy -= 10;
                }
                else
                {
                    Console.WriteLine("Недостаточно маны. Ты пропустил этот ход!");
                    Console.ReadLine();
                }
            }

            if (action == 2)
            {
                if (playerEnergy >= 40)
                {
                    enemyHealth -= 30;
                    playerEnergy -= 40;
                }
                else
                {
                    Console.WriteLine("Недостаточно маны. Ты пропустил этот ход!");
                    Console.ReadLine();
                }
            }

            if (action == 3)
            {
                playerEnergy += 20;
            }

            if (action == 4)
            {
                if (playerEnergy >= 20)
                {
                    playerHealth += 30;
                    playerEnergy -= 20;
                }
                else
                {
                    Console.WriteLine("Недостаточно маны. Ты пропустил этот ход!");
                    Console.ReadLine();
                }
            }

            action = rnd.Next(1, 5); // Получение действий противника
            if(enemyHealth <= 20)
            {
                action = 4;
            }
            if(enemyEnergy <= 20)
            {
                action = 3;
            }

            if (action == 1)  // Описание скиллов противника
            {
                if (enemyEnergy >= 10)
                {
                    playerHealth -= 20;
                    enemyEnergy -= 10;
                    Console.WriteLine("Вы получили 20 урона");
                    Console.ReadLine();

                }
                else
                {
                    Console.WriteLine("Недостаточно маны. Ты пропустил этот ход!");
                    Console.ReadLine();
                }
            }

            if (action == 2)
            {
                if (enemyEnergy >= 40)
                {
                    playerHealth -= 30;
                    enemyEnergy -= 40;
                    Console.WriteLine("Вы получили 30 урона");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Недостаточно маны. Ты пропустил этот ход!");
                    Console.ReadLine();
                }
            }

            if (action == 3)
            {
                enemyEnergy += 20;
                Console.WriteLine("Противник восстанавливает 20 маны");
                Console.ReadLine();
            }

            if (action == 4)
            {
                if (enemyEnergy >= 20)
                {
                    enemyHealth += 30;
                    enemyEnergy -= 20;
                    Console.WriteLine("Противник восстанавливает 30 жизни");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Недостаточно маны. Ты пропустил этот ход!");
                    Console.ReadLine();
                }
            }
        }
        Console.ReadLine();
    }
    }

