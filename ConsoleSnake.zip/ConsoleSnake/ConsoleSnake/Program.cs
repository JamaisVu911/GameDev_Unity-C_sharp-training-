﻿using System;


namespace ConsoleSnake
{
    class Program
    {
        // Параметры игры
        static int foodX;
        static int foodY;
        static int head_x = 20;
        static int head_y = 10;
        static int dir = 0;
        static int snakeLen = 10;
        static int[] body_x = new int[100];
        static int[] body_y = new int[100];
        static int playerScore = 0;
        static int HiScore = playerScore;
        static void SpawnFood()
        {
            Random rnd = new Random();

            foodX = rnd.Next(0, 120 - body_x[0]);
            if (foodX % 2 != 0) foodX += 1;

            foodY = rnd.Next(0, 40 - body_y[0]);
        }

        static void PlayerMove()
        {
            if (Console.KeyAvailable == true)
            {
                ConsoleKeyInfo key;
                Console.SetCursorPosition(0, 0);
                key = Console.ReadKey();
                Console.SetCursorPosition(0, 0);
                Console.Write("  ");

                if (key.Key == ConsoleKey.D && dir != 2) dir = 0;
                if (key.Key == ConsoleKey.S && dir != 3) dir = 1;
                if (key.Key == ConsoleKey.A && dir != 0) dir = 2;
                if (key.Key == ConsoleKey.W && dir != 1) dir = 3;
            }

            if (dir == 0) head_x += 2;
            if (dir == 1) head_y += 1;
            if (dir == 2) head_x -= 2;
            if (dir == 3) head_y -= 1;

            if (head_x < 0) head_x = 118;
            if (head_x > 118) head_x = 0;

            if (head_y < 0) head_y = 39;
            if (head_y > 39) head_y = 0;
        }


        static void Main()
        {
            // Параметры программы
            Console.SetWindowSize(120, 40);
            Console.SetBufferSize(120, 40);
            Console.CursorVisible = false;
            bool isGame = true;

            // Стартовое значение змейки
            for (int i = 0; i < snakeLen; i++)
            {
                body_x[i] = head_x - (i * 2);
                body_y[i] = 10;
            }

            // Стартовое значение еды
            SpawnFood();

            while (isGame == true)
            {
                if (playerScore > HiScore) HiScore = playerScore;
                // 1. Очистка
                for (int i = 0; i < snakeLen; i++)
                {
                    Console.SetCursorPosition(body_x[i], body_y[i]);
                    Console.Write("  ");
                }

                Console.SetCursorPosition(head_x, head_y);
                Console.Write("  ");

                Console.SetCursorPosition(foodX, foodY);
                Console.Write("  ");

                // 2. Расчеты
 
                // Движение змейки

                PlayerMove();


                for (int i = snakeLen; i > 0; i--)
                {
                    body_x[i] = body_x[i - 1];
                    body_y[i] = body_y[i - 1];
                }
                body_x[0] = head_x;
                body_y[0] = head_y;

                for (int i = 1; i < snakeLen; i++)
                {
                    if (body_x[i] == head_x && body_y[i] == head_y)
                    {
                        isGame = false;
                        Console.SetCursorPosition(1, 3);
                        Console.Write("Вы проиграли, для перезапуска игры нажмите R");
                        ConsoleKeyInfo key;
                        key = Console.ReadKey();
                        if (key.Key == ConsoleKey.R)
                        {
                            head_x = 20;
                            head_y = 10;
                            dir = 0;
                            snakeLen = 10;
                            body_x = new int[100];
                            body_y = new int[100];
                            playerScore = 0;
                            isGame = true;
                            Console.Clear();
                        }
                    }
                }
                // Бесконечное поле

                // Еда

                if(head_x == foodX && head_y == foodY)
                {
                    SpawnFood();
                    snakeLen++;
                    playerScore += 1;
                }

                // 3. Отрисовка
                for (int i = 0; i < snakeLen; i++)
                {
                    Console.SetCursorPosition(body_x[i], body_y[i]);
                    Console.Write("██");
                }

                // Ведение счета

                Console.SetCursorPosition(1, 1);
                Console.Write("Съедено Еды: " + playerScore);

                Console.SetCursorPosition(20, 1);
                Console.Write("Рекорд: " + HiScore);


                Console.SetCursorPosition(head_x, head_y);
                Console.Write("██");

                Console.SetCursorPosition(foodX, foodY);
                Console.Write("██");

                // 4. Ожидание

                System.Threading.Thread.Sleep(50);

            }
        }
    }
}
